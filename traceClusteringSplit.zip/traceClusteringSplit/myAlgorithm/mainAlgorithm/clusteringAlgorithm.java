package mainAlgorithm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class clusteringAlgorithm {

	public void run(String logAddress, String outputFold,
			String patternAddress, String numberAddress,
			Integer singleClusterNumberThreshold, double originalEdgeNumber,
			double originalDensity, double edgeNumberWeight,
			double densityWeight, double min_improvement,
			double casualRelationThreshold) {
		Long ll1 = System.currentTimeMillis();
		readInTraces rd = new readInTraces(logAddress);
		HashMap<String, String> mapTrace = rd.readIn();
		dealWithPattern dp = new dealWithPattern();
		HashMap<String, String> ns = dp.readNS(numberAddress);
		ArrayList<String> patternList = dp.readInPatterns(ns, patternAddress);
		splitOneIntoTwo(mapTrace, outputFold, patternList,
				singleClusterNumberThreshold, originalEdgeNumber,
				originalDensity, edgeNumberWeight, densityWeight,
				min_improvement, casualRelationThreshold);
		Long ll2 = System.currentTimeMillis();
		System.out.println("mining pattern running duration: " + (ll2 - ll1)
				+ "ms");
	}

	public void splitOneIntoTwo(HashMap<String, String> mapTrace,
			String outputFold, ArrayList<String> patternList,
			Integer singleClusterNumberThreshold, double originalEdgeNumber,
			double originalDensity, double edgeNumberWeight,
			double densityWeight, double min_improvement,
			double casualRelationThreshold) {
		solveLog sl = new solveLog();
		String pattern = null;
		ArrayList<HashMap<String, String>> list = null;
		ArrayList<HashMap<String, String>> maxlist = null;
		double maxValue = -100.0;
		double tValue = 0.0;
		String[] vv = null;
		double averageNumber = 0;
		double averageDen = 0.0;
		double d1 = 0.0d;
		double d2 = 0.0d;
		for (int i = 0; i < patternList.size(); i++) {
			pattern = patternList.get(i);
			list = sl.splitTraces(pattern, mapTrace,
					singleClusterNumberThreshold);
			if (list == null)
				continue;
			vv = calculateAverageMetrics(list, casualRelationThreshold).split(
					"_Vsplit_");
			averageNumber = Double.parseDouble(vv[0]);
			averageDen = Double.parseDouble(vv[1]);
			d1 = Math
					.round((((double) (originalEdgeNumber - averageNumber)) / originalEdgeNumber) * 10000) / 10000.0;
			d2 = Math
					.round((((double) (originalDensity - averageDen)) / originalDensity) * 10000) / 10000.0;
			tValue = edgeNumberWeight * d1 + densityWeight * d2;
			if (tValue > maxValue) {
				maxValue = tValue;
				maxlist = list;
			}
		}
		if (maxValue < min_improvement)
			System.out.println("should not go on splitting this log");
		else {
			generateInformationOfGeneratedLogs(maxlist);
			output(maxlist, outputFold);
		}
	}

	public void generateInformationOfGeneratedLogs(
			ArrayList<HashMap<String, String>> maxlist) {
		HashMap<String, String> map = maxlist.get(2);
		String[] withMap = map.get("withMap").split("_Vsplit_");
		String[] withoutMap = map.get("withoutMap").split("_Vsplit_");
		System.out.println("withMap EdgeNumber is: " + withMap[0]
				+ ", density is: " + withMap[1]
				+ ", withoutMap EdgeNumber is: " + withoutMap[0]
				+ ", density is: " + withoutMap[1]);
	}

	public void output(ArrayList<HashMap<String, String>> list, String fold) {
		HashMap<String, String> withMap = list.get(0);
		HashMap<String, String> withoutMap = list.get(1);
		generateXES g = new generateXES();
		g.generateEventLogWithOutSE(withMap, fold + "withMap.xes");
		g.generateEventLogWithOutSE(withoutMap, fold + "withoutMap.xes");
	}

	// ������������־��ƽ��metics,��Ҫ��ÿ��log�������ϢҲ����list
	public String calculateAverageMetrics(
			ArrayList<HashMap<String, String>> list,
			double casualRelationThreshold) {
		HashMap<String, String> withMap = list.get(0);
		HashMap<String, String> withoutMap = list.get(1);
		String[] forWithMap = calculateForOneLog(withMap,
				casualRelationThreshold).split("_Vsplit_");
		int withMapEdgeNumberValue = Integer.parseInt(forWithMap[0]);
		double withMapDensityValue = Double.parseDouble(forWithMap[1]);
		String[] forWithoutMap = calculateForOneLog(withoutMap,
				casualRelationThreshold).split("_Vsplit_");
		int withoutMapEdgeNumberValue = Integer.parseInt(forWithoutMap[0]);
		double withoutMapDensityValue = Double.parseDouble(forWithoutMap[1]);
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("withMap", String.valueOf(withMapEdgeNumberValue) + "_Vsplit_"
				+ String.valueOf(withMapDensityValue));
		map.put("withoutMap", String.valueOf(withoutMapEdgeNumberValue)
				+ "_Vsplit_" + String.valueOf(withoutMapDensityValue));
		list.add(map);
		Integer n1 = withMap.size();
		Integer n2 = withoutMap.size();
		double averageEdgeNumber = Math
				.round((((double) (withMapEdgeNumberValue * n1 + withoutMapEdgeNumberValue
						* n2)) / (n1 + n2)) * 10000) / 10000.0;
		double averageDensity = Math
				.round((((double) (withMapDensityValue * n1 + withoutMapDensityValue
						* n2)) / (n1 + n2)) * 10000) / 10000.0;
		return String.valueOf(averageEdgeNumber) + "_Vsplit_"
				+ String.valueOf(averageDensity);
	}

	public String calculateForOneLog(HashMap<String, String> mapTrace,
			double casualRelationThreshold) {
		generateRelationFile gr = new generateRelationFile();
		HashMap<String, String> relationMap = gr.run(mapTrace,
				casualRelationThreshold);
		Integer edgeNumber = getEdgeNumber(relationMap);
		Set<String> set = mapTrace.keySet();
		Iterator iterator = set.iterator();
		ArrayList<String> kset = new ArrayList<String>();
		while (iterator.hasNext()) {
			kset.add(iterator.next().toString());
		}
		ArrayList<String> list = new ArrayList<String>();
		String key = null;
		String[] value = null;
		for (int i = 0; i < kset.size(); i++) {
			key = kset.get(i);
			value = mapTrace.get(key).split("_Asplit_");
			for (int j = 0; j < value.length; j++) {
				if (!list.contains(value[j]))
					list.add(value[j]);
			}
		}
		int anumber = list.size();
		double density = Math
				.round((((double) edgeNumber) / (anumber * (anumber - 1))) * 10000) / 10000.0;
		return String.valueOf(edgeNumber) + "_Vsplit_"
				+ String.valueOf(density);
	}

	public int getEdgeNumber(HashMap<String, String> relationMap) {
		Set<String> set = relationMap.keySet();
		Iterator iterator = set.iterator();
		ArrayList<String> kset = new ArrayList<String>();
		while (iterator.hasNext()) {
			kset.add(iterator.next().toString());
		}
		Integer number = 0;
		String key = null;
		String[] value = null;
		for (int i = 0; i < kset.size(); i++) {
			key = kset.get(i);
			value = relationMap.get(key).split("_Asplit_");
			number = number + value.length;
		}
		return number;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// for ICP: originalEdgeNumber:41 originalDensity:0.009,
		// edgeWeight:0.8,densityWeight:0.2
		clusteringAlgorithm ca = new clusteringAlgorithm();
		ca.run("C:\\Users\\sun\\Desktop\\traceClustering-splitExperiment\\icp\\3-2-1-without-without\\withMap.xes",
				"C:\\Users\\sun\\Desktop\\traceClustering-splitExperiment\\icp\\4-3-2-1-without-without-with\\",
				"C:\\Users\\sun\\Desktop\\traceClustering-splitExperiment\\icp\\pattern.txt",
				"C:\\Users\\sun\\Desktop\\traceClustering-splitExperiment\\icp\\Name-Number.txt",
				100, 16, 0.0052, 0.8, 0.2, 0, 0.9);
	}

}
