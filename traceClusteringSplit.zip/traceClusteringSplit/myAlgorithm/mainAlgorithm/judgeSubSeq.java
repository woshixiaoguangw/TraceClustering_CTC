package mainAlgorithm;

import java.util.ArrayList;
import java.util.HashMap;

public class judgeSubSeq {

	// string�еĸ����ʻ�ʵ��_������
	public Integer findSubSequence(String s1, String s2) {
		String[] trace = s1.split("_");
		String[] spattern = s2.split("_");
		int index = 0;
		int i = 0;
		int j = 0;
		for (; i < spattern.length; i++) {
			for (; j < trace.length; j++) {
				if (!spattern[i].equals(trace[j]))
					continue;
				else
					break;
			}
			if (j == trace.length)
				break;
		}
		// System.out.println("i: " + i);
		// System.out.println("j: " + j);
		if (i == spattern.length)
			return 1;
		else
			return 0;
	}

	// �ҵ�trace��spattern�����lncs����lncs����spattern�ĳ�����Ϊ����ֵ,���������ֵ����victor.
	// �����Կ���ÿ��activity��Ȩ��������victor??????
	public Double findLNCS(String trace, String spattern) {
		Integer m = trace.split("_").length;
		Integer n = spattern.split("_").length;
		Integer[][] c = new Integer[m + 1][n + 1];
		Character[][] b = new Character[m + 1][n + 1];
		c[0][0] = 0;
		String[] t = trace.split("_");
		String[] s = spattern.split("_");
		String[] tra = new String[t.length + 1];
		String[] spa = new String[s.length + 1];
		Integer len = 0;
		for (int i = 1; i < tra.length; i++) {
			tra[i] = t[i - 1];
			// System.out.println(tra[i]);
		}
		for (int i = 1; i < spa.length; i++) {
			spa[i] = s[i - 1];
			// System.out.println(spa[i]);
		}
		for (int i = 0; i <= m; i++) {
			c[i][0] = 0;
		}
		for (int j = 0; j <= n; j++) {
			c[0][j] = 0;
		}
		for (int i = 1; i <= m; i++) {
			for (int j = 1; j <= n; j++) {
				if (tra[i].equals(spa[j])) {
					c[i][j] = c[i - 1][j - 1] + 1;
					b[i][j] = 'm';
				} else if (c[i - 1][j] >= c[i][j - 1]) {
					c[i][j] = c[i - 1][j];
					b[i][j] = 'u';
				} else {
					c[i][j] = c[i][j - 1];
					b[i][j] = 'l';
				}
			}
		}
		// System.out.println(c[m][n]);
		return ((double) c[m][n]) / ((double) n);
	}

	// ������������г���, ��traceclustering�㷨�����������,��סpatternҪ��������ȥfrequency��
	public Integer findLNCS1(String trace, String spattern) {
		Integer m = trace.split("_Asplit_").length;
		Integer n = spattern.split("_Asplit_").length;
		Integer[][] c = new Integer[m + 1][n + 1];
		Character[][] b = new Character[m + 1][n + 1];
		c[0][0] = 0;
		String[] t = trace.split("_Asplit_");
		String[] s = spattern.split("_Asplit_");
		String[] tra = new String[t.length + 1];
		String[] spa = new String[s.length + 1];
		Integer len = 0;
		for (int i = 1; i < tra.length; i++) {
			tra[i] = t[i - 1];
			// System.out.println(tra[i]);
		}
		for (int i = 1; i < spa.length; i++) {
			spa[i] = s[i - 1];
			// System.out.println(spa[i]);
		}
		for (int i = 0; i <= m; i++) {
			c[i][0] = 0;
		}
		for (int j = 0; j <= n; j++) {
			c[0][j] = 0;
		}
		for (int i = 1; i <= m; i++) {
			for (int j = 1; j <= n; j++) {
				if (tra[i].equals(spa[j])) {
					c[i][j] = c[i - 1][j - 1] + 1;
					b[i][j] = 'm';
				} else if (c[i - 1][j] >= c[i][j - 1]) {
					c[i][j] = c[i - 1][j];
					b[i][j] = 'u';
				} else {
					c[i][j] = c[i][j - 1];
					b[i][j] = 'l';
				}
			}
		}
		// System.out.println(c[m][n]);
		return c[m][n];
	}

	// ������������г���
	public Integer findLNCS2(String trace, String spattern) {
		Integer m = trace.split("-").length;
		Integer n = spattern.split(" ").length;
		Integer[][] c = new Integer[m + 1][n + 1];
		Character[][] b = new Character[m + 1][n + 1];
		c[0][0] = 0;
		String[] t = trace.split("-");
		String[] s = spattern.split(" ");
		String[] tra = new String[t.length + 1];
		String[] spa = new String[s.length + 1];
		Integer len = 0;
		for (int i = 1; i < tra.length; i++) {
			tra[i] = t[i - 1];
			// System.out.println(tra[i]);
		}
		for (int i = 1; i < spa.length; i++) {
			spa[i] = s[i - 1];
			// System.out.println(spa[i]);
		}
		for (int i = 0; i <= m; i++) {
			c[i][0] = 0;
		}
		for (int j = 0; j <= n; j++) {
			c[0][j] = 0;
		}
		for (int i = 1; i <= m; i++) {
			for (int j = 1; j <= n; j++) {
				if (tra[i].equals(spa[j])) {
					c[i][j] = c[i - 1][j - 1] + 1;
					b[i][j] = 'm';
				} else if (c[i - 1][j] >= c[i][j - 1]) {
					c[i][j] = c[i - 1][j];
					b[i][j] = 'u';
				} else {
					c[i][j] = c[i][j - 1];
					b[i][j] = 'l';
				}
			}
		}
		// System.out.println(c[m][n]);
		return c[m][n];
	}

	// ������������г���
	public Integer findLNCS3(String trace, String spattern) {
		Integer m = trace.split(" ").length;
		Integer n = spattern.split(" ").length;
		Integer[][] c = new Integer[m + 1][n + 1];
		Character[][] b = new Character[m + 1][n + 1];
		c[0][0] = 0;
		String[] t = trace.split(" ");
		String[] s = spattern.split(" ");
		String[] tra = new String[t.length + 1];
		String[] spa = new String[s.length + 1];
		Integer len = 0;
		for (int i = 1; i < tra.length; i++) {
			tra[i] = t[i - 1];
			// System.out.println(tra[i]);
		}
		for (int i = 1; i < spa.length; i++) {
			spa[i] = s[i - 1];
			// System.out.println(spa[i]);
		}
		for (int i = 0; i <= m; i++) {
			c[i][0] = 0;
		}
		for (int j = 0; j <= n; j++) {
			c[0][j] = 0;
		}
		for (int i = 1; i <= m; i++) {
			for (int j = 1; j <= n; j++) {
				if (tra[i].equals(spa[j])) {
					c[i][j] = c[i - 1][j - 1] + 1;
					b[i][j] = 'm';
				} else if (c[i - 1][j] >= c[i][j - 1]) {
					c[i][j] = c[i - 1][j];
					b[i][j] = 'u';
				} else {
					c[i][j] = c[i][j - 1];
					b[i][j] = 'l';
				}
			}
		}
		// System.out.println(c[m][n]);
		return c[m][n];
	}

	// ��һ��traceӳ�䵽victor��, ������һ��trace�� һ��sequential
	// pattern����.Ҳ���Կ����ñ���֤�ĳ��ȳ����ܳ�������victorֵ
	public ArrayList<Double> changeToVitor(String trace,
			HashMap<Integer, String> spMap) {
		ArrayList<Double> list = new ArrayList<Double>();
		for (int i = 1; i <= spMap.size(); i++) {
			String pattern = spMap.get(i);
			Double bool = findLNCS(trace, pattern);
			list.add(bool);
		}
		return list;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		judgeSubSeq s = new judgeSubSeq();
		String trace = "s_y_j_m_a_b_c_k_m_n_a_b";
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		map.put(1, "s_y_j_m_a_b_c_k_m_n_a_b");
		map.put(2, "k_y_t_j");
		map.put(3, "m_m_a");
		map.put(4, "s_j_n_c");
		System.out.println(s.changeToVitor(trace, map));
		String trace1 = "a b q d m n f k k f j l o y z t f t t l k f";
		String spattern1 = "t a b q d m n f k k f j l o t f g o";
		System.out.println(s.findLNCS1(trace1, spattern1));
	}

}
