package mainAlgorithm;

import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import org.deckfour.xes.in.XesXmlParser;
import org.deckfour.xes.model.XEvent;
import org.deckfour.xes.model.XLog;
import org.deckfour.xes.model.XTrace;

public class readInTraces {
	FileInputStream fis = null;
	BufferedInputStream bis = null;
	XesXmlParser xxp = null;

	public readInTraces(String file) {
		try {
			fis = new FileInputStream(file);
			bis = new BufferedInputStream(fis);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		xxp = new XesXmlParser();
	}

	// ��ȡ��������traces,��ʽ��map(traceid,activity_activity)
	public HashMap<String, String> readIn() {
		HashMap<String, String> mapTrace = new HashMap<String, String>();
		ArrayList<XLog> list = null;
		String s = null; // �����洢trace
		Integer m = 0;
		String index = null;
		try {
			list = (ArrayList<XLog>) xxp.parse(bis);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// System.out.println(list.get(0));
		XLog xlog = list.get(0);
		for (XTrace trace : xlog) {
			index = trace.getAttributes().get("concept:name").toString();
			for (XEvent event : trace) {
				m++;
				if (m == 1) {
					s = event.getAttributes().get("concept:name").toString()
							+ "_Tsplit_" // name��transition֮��ķ������������
							+ event.getAttributes().get("lifecycle:transition")
									.toString();
				} else if (m == trace.size()) {
					s = s
							+ "_Asplit_" // activity��activity֮�����������
							+ event.getAttributes().get("concept:name")
									.toString()
							+ "_Tsplit_"
							+ event.getAttributes().get("lifecycle:transition")
									.toString();
				} else {
					s = s
							+ "_Asplit_"
							+ event.getAttributes().get("concept:name")
									.toString()
							+ "_Tsplit_"
							+ event.getAttributes().get("lifecycle:transition")
									.toString();
				}

			}
			// String fs = checkDuplicatedActivity(s);
			mapTrace.put(index, s);
			m = 0;
		}
		try {
			fis.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// Set<String> set = mapTrace.keySet();
		// Iterator iterator = set.iterator();
		// ArrayList<String> kset = new ArrayList<String>();
		// while (iterator.hasNext()) {
		// kset.add(iterator.next().toString());
		// }
		// String stest = null;
		// for (int i = 0; i < kset.size(); i++) {
		// stest = kset.get(i);
		// System.out.println(stest + ": " + mapTrace.get(stest));
		// }
		// System.out.println(mapTrace);
		return mapTrace;
	}

	// ����汾�е�activity���������ٵ�department���֣���activity-department��ͬʱ����ÿ��trace��Ӧ��treatment�ļ�
	/*
	 * public HashMap<String, String> readInByTreatment() { FileWriter fw =
	 * null; BufferedWriter bw = null; PrintWriter pw = null; try { fw = new
	 * FileWriter(new File(
	 * "C:\\Users\\sun\\Desktop\\����1\\trace-treatment.txt")); bw = new
	 * BufferedWriter(fw); pw = new PrintWriter(bw); } catch (IOException e) {
	 * // TODO Auto-generated catch block e.printStackTrace(); } HashMap<String,
	 * String> mapTrace = new HashMap<String, String>(); ArrayList<XLog> list =
	 * null; String s = null; // �����洢trace Integer m = 0; String index = null;
	 * String department = null; String tm = null; String tm1 = null; // Integer
	 * count=0; try { list = (ArrayList<XLog>) xxp.parse(bis); } catch
	 * (Exception e) { // TODO Auto-generated catch block e.printStackTrace(); }
	 * // System.out.println(list.get(0)); XLog xlog = list.get(0); for (XTrace
	 * trace : xlog) { if (trace.getAttributes().get("Treatment code") != null)
	 * tm = trace.getAttributes().get("Treatment code").toString(); else tm =
	 * "null"; if (trace.getAttributes().get("Treatment code:1") == null) tm1 =
	 * "null"; else tm1 = " "; if (!configure.contains(tm) ||
	 * !tm1.equals("null")) continue; // if(tm.equals("803")) // count++; index
	 * = trace.getAttributes().get("concept:name").toString(); pw.println(index
	 * + " : " + tm); for (XEvent event : trace) { department =
	 * checkBlankSpace(event.getAttributes().get( "org:group").toString()); m++;
	 * if (m == 1) { s = removeSPOED(recoveDuplicatedLine(checkBlankSpace(event
	 * .getAttributes().get("concept:name").toString()))) + "-" + department; }
	 * else if (m == trace.size()) { s = s + "_" +
	 * removeSPOED(recoveDuplicatedLine(checkBlankSpace(event
	 * .getAttributes().get("concept:name") .toString()))) + "-" + department; }
	 * else { s = s + "_" +
	 * removeSPOED(recoveDuplicatedLine(checkBlankSpace(event
	 * .getAttributes().get("concept:name") .toString()))) + "-" + department; }
	 * 
	 * } // String fs = checkDuplicatedActivity(s); mapTrace.put(index, s); m =
	 * 0; } try { fis.close(); pw.close(); } catch (IOException e) { // TODO
	 * Auto-generated catch block e.printStackTrace(); }
	 * System.out.println("trace size: " + mapTrace.size()); return mapTrace; }
	 */

	// ɾ��һ��event���ֵĿո�
	public String checkBlankSpace(String s) {
		char[] c = s.toCharArray();
		String r = null;
		for (int i = 0; i < c.length; i++) {
			if (c[i] == ' ') {
				c[i] = '-';
			}
			if (i == 0)
				r = String.valueOf(c[i]);
			else
				r = r + String.valueOf(c[i]);
		}
		return r;
	}

	// ɾ��activity�����е�spoed
	public String removeSPOED(String activity) {
		char[] ac = activity.toCharArray();
		Integer leng = ac.length;
		String s = null;
		String s1 = null;
		Integer j = 6;
		if (leng > 5) {
			// System.out.println("ddd");
			for (int i = 5; i >= 1; i--) {
				if (i == 5) {
					s = String.valueOf(ac[leng - i]);
				} else
					s = s + String.valueOf(ac[leng - i]);
			}
		} else
			return activity;
		if (s.equals("spoed")) {
			while (ac[leng - j] == ' ' || ac[leng - j] == '-') {
				j++;
			}
			for (int i = 0; i <= leng - j; i++) {
				if (i == 0)
					s1 = String.valueOf(ac[i]);
				else
					s1 = s1 + String.valueOf(ac[i]);

			}
			return s1;
		} else
			return activity;
	}

	public String recoveDuplicatedLine(String activity) {
		char[] ac = activity.toCharArray();
		Integer len = ac.length;
		String ret = null;
		char tem = ' ';
		for (int i = 0; i < len; i++) {
			if (i == 0) {
				ret = String.valueOf(ac[i]);
				tem = ac[i];
			} else {
				if (tem == '-' && ac[i] == '-')
					continue;
				else {
					ret = ret + String.valueOf(ac[i]);
					tem = ac[i];
				}
			}
		}
		return ret;
	}

	// ��һ��trace����ظ������ӱ�ţ����Ϊ�ظ�����ظ���
	public String checkDuplicatedActivity(String s) {
		String[] ss = s.split("_");
		String fs = null;
		for (int i = 0; i < ss.length - 1; i++) {
			String s1 = ss[i];
			if (s1.split("_").length != 1)
				continue;
			Integer m = 1;
			for (int j = i + 1; j < ss.length; j++) {
				if (s1.equals(ss[j])) {
					ss[j] = ss[j] + "_" + m;
					m++;
				}
			}
		}
		for (int i = 0; i < ss.length; i++) {
			if (i == 0)
				fs = checkBlankSpace(ss[i]);
			else
				fs = fs + "_" + checkBlankSpace(ss[i]);
		}
		return fs;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * readInTraces rit = new readInTraces(
		 * "C:\\Users\\sun\\Desktop\\Hospital_log.xes"); HashMap<String, String>
		 * m = rit.readInByTreatment(); System.out.println(m.size());
		 * Set<String> set = m.keySet(); Iterator iterator = set.iterator();
		 * ArrayList<String> kset = new ArrayList<String>(); while
		 * (iterator.hasNext()) { kset.add(iterator.next().toString()); }
		 * System.out.println(kset);
		 */
	}

}
