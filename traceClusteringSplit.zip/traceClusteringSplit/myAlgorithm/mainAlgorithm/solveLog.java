package mainAlgorithm;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class solveLog {

	// ����pattern��split traces,�����������ϵ�����trace��id
	public ArrayList<HashMap<String, String>> splitTraces(String pattern,
			HashMap<String, String> mapTrace, Integer threshold) {
		HashMap<String, String> withMap = new HashMap<String, String>();
		HashMap<String, String> withoutMap = new HashMap<String, String>();
		ArrayList<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();
		judgeSubSeq jss = new judgeSubSeq();
		String patt = pattern.split("_FRsplit_")[0];
		Set<String> set = mapTrace.keySet();
		Iterator iterator = set.iterator();
		ArrayList<String> kset = new ArrayList<String>();
		while (iterator.hasNext()) {
			kset.add(iterator.next().toString());
		}
		String key = null;
		String value = null;
		int leng = patt.split("_Asplit_").length;
		int index = 0;
		for (int i = 0; i < kset.size(); i++) {
			key = kset.get(i);
			value = mapTrace.get(key);
			index = jss.findLNCS1(value, patt);
			// System.out.println(index);
			if (index == leng) {
				withMap.put(key, mapTrace.get(key));
			} else {
				withoutMap.put(key, mapTrace.get(key));
			}
		}
		list.add(withMap);
		list.add(withoutMap);
		if (withMap.size() < threshold || withoutMap.size() < threshold)
			return null;
		return list;
		// ��������id��trace��������Ÿ���,ǰ�����pattern��traces�����治����
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		solveLog r = new solveLog();
		String pattern = "a_Asplit_b_Asplit_d_FRsplit_43";
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("1", "a_Asplit_e_Asplit_d_Asplit_f_Asplit_b_Asplit_d");
		map.put("2", "a");
		map.put("3", "a_Asplit_e_Asplit_f_Asplit_b");
		map.put("4", "a_Asplit_e_Asplit_d_Asplit_f_Asplit_f_Asplit_q");
		// System.out.println(r.splitTraces(pattern, map));
	}

}
