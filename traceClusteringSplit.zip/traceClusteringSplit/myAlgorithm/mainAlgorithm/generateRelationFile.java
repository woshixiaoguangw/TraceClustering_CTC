package mainAlgorithm;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class generateRelationFile {

	public HashMap<String, String> run(HashMap<String, String> mapTrace,
			double threshold) {
		// ����Ҫ����ͬ����־���//////////////////////////////////////////////////////////////
		HashMap<String, String> matrix = generateMatrix(mapTrace);
		HashMap<String, String> relation = generateRelation(matrix, threshold);
		return relation;
	}

	// ��ӡ��layout��Ҫ�ĸ�ʽ
	public void outputDataWithWeight(HashMap<String, String> bMap,
			String address) {
		FileWriter fw = null;
		BufferedWriter bw = null;
		PrintWriter pw = null;
		try {
			fw = new FileWriter(new File(address)); // ����Ҫ���ű��
			bw = new BufferedWriter(fw);
			pw = new PrintWriter(bw);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Set<String> set = bMap.keySet();
		Iterator iterator = set.iterator();
		ArrayList<String> kset = new ArrayList<String>();
		while (iterator.hasNext()) {
			kset.add(iterator.next().toString());
		}
		String key = null;
		String value = null;
		String[] s1 = null;
		for (int i = 0; i < kset.size(); i++) {
			key = kset.get(i);
			value = bMap.get(key);
			// System.out.println("key:" + key);
			// System.out.println(value);
			s1 = value.split("_Asplit_");
			for (int j = 0; j < s1.length; j++) {
				// System.out.println(s1[j]);
				pw.println(key + "_Asplit_" + s1[j] + "_Asplit_" + 1);
			}
		}
		pw.close();
	}

	// ����casual matrix��threshold�������յ�activtiy֮��Ĺ�ϵ
	public HashMap<String, String> generateRelation(
			HashMap<String, String> matrix, double threshold) {
		HashMap<String, String> relation = new HashMap<String, String>();
		Set<String> set = matrix.keySet();
		Iterator iterator = set.iterator();
		ArrayList<String> kset = new ArrayList<String>();
		while (iterator.hasNext()) {
			kset.add(iterator.next().toString());
		}
		String key = null;
		String[] value = null;
		for (int i = 0; i < kset.size(); i++) {
			String s1 = null;
			key = kset.get(i);
			value = matrix.get(key).split("_Asplit_");
			s1 = checkActivity(key, value, matrix, threshold);
			if (s1 != null)
				relation.put(key, s1);
		}
		return relation;
	}

	public String checkActivity(String key, String[] value,
			HashMap<String, String> matrix, double threshold) {
		Integer f = 0;
		String act = null;
		String result = null;
		ArrayList<String> list = new ArrayList<String>();
		Integer num = 0;
		double cv = 0d;
		for (int i = 0; i < value.length; i++) {
			f = Integer.parseInt(value[i].split("_Fsplit_")[1]);
			act = value[i].split("_Fsplit_")[0];
			num = check(key, act, matrix);
			cv = ((double) (f - num)) / (f + num + 1);
			// System.out.println(key + "->" + act + ": " + cv);
			if (cv > threshold)
				list.add(act);
		}
		if (list.size() == 0)
			return null;
		for (int i = 0; i < list.size(); i++) {
			if (i == 0)
				result = list.get(i);
			else
				result = result + "_Asplit_" + list.get(i);
		}
		return result;
	}

	public Integer check(String key, String act, HashMap<String, String> matrix) {
		if (!matrix.containsKey(act))
			return 0;
		String[] value = matrix.get(act).split("_Asplit_");
		Integer f = 0;
		String a = null;
		for (int i = 0; i < value.length; i++) {
			f = Integer.parseInt(value[i].split("_Fsplit_")[1]);
			a = value[i].split("_Fsplit_")[0];
			if (a.equals(key))
				return f;
		}
		return 0;
	}

	// ����casual
	// matrix,��ʽ��һ��keyΪһ��activity��ֵ��activity_Fsplit_f_Asplit_activity_Fsplit_f
	public HashMap<String, String> generateMatrix(
			HashMap<String, String> mapTrace) {
		HashMap<String, String> matrix = new HashMap<String, String>();
		Set<String> set = mapTrace.keySet();
		Iterator iterator = set.iterator();
		ArrayList<String> kset = new ArrayList<String>();
		while (iterator.hasNext()) {
			kset.add(iterator.next().toString());
		}
		String key = null;
		String[] value = null;
		for (int i = 0; i < kset.size(); i++) {
			key = kset.get(i);
			value = mapTrace.get(key).split("_Asplit_");
			addElementForMatrix(matrix, value);
		}
		return matrix;
	}

	public void addElementForMatrix(HashMap<String, String> matrix,
			String[] value) {
		String[] s1 = null;
		if (value.length != 1)
			for (int i = 0; i < value.length - 1; i++) {
				if (!matrix.containsKey(value[i])
						&& !value[i].equals(value[i + 1]))
					matrix.put(value[i], value[i + 1] + "_Fsplit_" + 1);
				else if (matrix.containsKey(value[i])
						&& !value[i].equals(value[i + 1])) {
					s1 = matrix.get(value[i]).split("_Asplit_");
					matrix.put(value[i], add(s1, value[i + 1]));
				}
			}
	}

	public String add(String[] s1, String value) {
		String result = null;
		String act = null;
		Integer f = null;
		Integer judge = 0;
		for (int i = 0; i < s1.length; i++) {
			act = s1[i].split("_Fsplit_")[0];
			f = Integer.parseInt(s1[i].split("_Fsplit_")[1]);
			if (act.equals(value)) {
				f++;
				judge = 1;
			}
			if (i == 0)
				result = act + "_Fsplit_" + f;
			else
				result = result + "_Asplit_" + act + "_Fsplit_" + f;
		}
		if (judge == 0)
			result = result + "_Asplit_" + value + "_Fsplit_" + 1;
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		generateRelationFile g = new generateRelationFile();
		// g.run("C:\\Users\\sun\\Desktop\\2012_E.xes",
		// "C:\\Users\\sun\\Desktop\\l.txt", 0);
	}
}
