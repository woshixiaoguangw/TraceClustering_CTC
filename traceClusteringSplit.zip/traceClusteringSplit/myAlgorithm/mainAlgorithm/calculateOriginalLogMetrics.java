package mainAlgorithm;

import java.util.HashMap;

public class calculateOriginalLogMetrics {
	public void calculate(String logAddress, double threshold) {
		readInTraces rd = new readInTraces(logAddress);
		HashMap<String, String> mapTrace = rd.readIn();
		clusteringAlgorithm c = new clusteringAlgorithm();
		String t = c.calculateForOneLog(mapTrace, threshold);
		System.out.println("edgeNumber_Vsplit_density: " + t);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		calculateOriginalLogMetrics c = new calculateOriginalLogMetrics();
		c.calculate("C:\\Users\\sun\\Desktop\\ICP_withoutArtificial.xes", 0.9);
	}

}
