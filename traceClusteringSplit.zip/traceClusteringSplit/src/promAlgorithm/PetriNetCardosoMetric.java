package promAlgorithm;

import java.util.HashSet;
import java.util.Set;

import org.processmining.framework.plugin.PluginContext;
import org.processmining.models.graphbased.directed.DirectedGraphEdge;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.graphbased.directed.petrinet.elements.Place;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.pnanalysis.metrics.PetriNetMetric;

public class PetriNetCardosoMetric implements PetriNetMetric {

	public final static String NAME = "Extended Cardoso metric";
	private StringBuffer buffer;

	public double compute(Petrinet net, Marking marking) {
		int metric = 0;
		buffer = new StringBuffer();
		for (Place place : net.getPlaces()) {
			Set<Set<Place>> successorPlaces = new HashSet<Set<Place>>();
			for (DirectedGraphEdge<?, ?> placeEdge : net.getOutEdges(place)) {
				Set<Place> successors = new HashSet<Place>();
				for (DirectedGraphEdge<?, ?> transitionEdge : net
						.getOutEdges(placeEdge.getTarget())) {
					successors.add((Place) transitionEdge.getTarget());
				}
				successorPlaces.add(successors);
			}
			buffer.append("Place " + place.getLabel() + " = "
					+ successorPlaces.size() + "\n");
			metric += successorPlaces.size();
		}
		buffer.append("Metric = " + metric + "\n");
		return metric;
	}

	public String getName() {
		return NAME;
	}

	public StringBuffer getLog() {
		return buffer;
	}

	@Override
	public double compute(PluginContext context, Petrinet net, Marking marking) {
		// TODO Auto-generated method stub
		return 0;
	}
}
