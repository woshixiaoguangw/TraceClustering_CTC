package promAlgorithm;

import org.processmining.framework.plugin.PluginContext;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.pnanalysis.metrics.PetriNetMetric;

public class PetriNetDensityMetric implements PetriNetMetric {

	public final static String NAME = "Density metric";
	private StringBuffer buffer;

	public double compute(Petrinet net, Marking marking) {
		buffer = new StringBuffer();
		buffer.append("|F| = " + net.getEdges().size() + "\n");
		buffer.append("|P X T| = " + (net.getPlaces().size() * net.getTransitions().size()) + "\n");
		return net.getEdges().size()
				/ (2.0 * net.getPlaces().size() * net.getTransitions().size());
	}

	public String getName() {
		return NAME;
	}


	public StringBuffer getLog() {
		return buffer;
	}

	@Override
	public double compute(PluginContext context, Petrinet net, Marking marking) {
		// TODO Auto-generated method stub
		return 0;
	}
}
