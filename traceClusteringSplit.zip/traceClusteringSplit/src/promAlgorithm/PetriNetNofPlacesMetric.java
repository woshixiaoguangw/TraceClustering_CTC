package promAlgorithm;

import org.processmining.framework.plugin.PluginContext;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.semantics.petrinet.Marking;
import org.processmining.pnanalysis.metrics.PetriNetMetric;

public class PetriNetNofPlacesMetric implements PetriNetMetric {

	public final static String NAME = "Number of places";
	
	public double compute(Petrinet net, Marking marking) {
		return net.getPlaces().size();
	}

	public String getName() {
		return NAME;
	}


	public StringBuffer getLog() {
		return new StringBuffer();
	}

	@Override
	public double compute(PluginContext context, Petrinet net, Marking marking) {
		// TODO Auto-generated method stub
		return 0;
	}
}
