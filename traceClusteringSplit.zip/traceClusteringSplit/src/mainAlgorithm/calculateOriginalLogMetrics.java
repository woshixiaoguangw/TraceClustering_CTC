package mainAlgorithm;

import java.util.HashMap;

import org.deckfour.xes.model.XLog;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.heuristics.HeuristicsNet;
import org.processmining.models.semantics.petrinet.Marking;

import promAlgorithm.FlexibleHeuristicsMiner;
import promAlgorithm.HeuristicsNetToPetriNetConverter;
import promAlgorithm.PetriNetCardosoMetric;
import promAlgorithm.PetriNetDensityMetric;
import promAlgorithm.PetriNetNofArcsMetric;
import promAlgorithm.PetriNetNofPlacesMetric;
import promAlgorithm.PetriNetNofTransitionsMetric;
import assist1.solveLog;

public class calculateOriginalLogMetrics {
	public void calculate(String logAddress) {
		solveLog sl = new solveLog();
		XLog xl = sl.openLogXES(logAddress);
		FlexibleHeuristicsMiner miner = new FlexibleHeuristicsMiner(xl);
		HeuristicsNetToPetriNetConverter hv = new HeuristicsNetToPetriNetConverter();
		HeuristicsNet hn = miner.mine();
		Object[] o = hv.converter(hn);
		Petrinet net = (Petrinet) o[0];
		Marking m = (Marking) o[1];
		PetriNetNofArcsMetric ar = new PetriNetNofArcsMetric();
		PetriNetNofPlacesMetric pl = new PetriNetNofPlacesMetric();
		PetriNetNofTransitionsMetric tr = new PetriNetNofTransitionsMetric();
		PetriNetCardosoMetric ca = new PetriNetCardosoMetric();
		PetriNetDensityMetric de = new PetriNetDensityMetric();
		// String fitness = String.valueOf(hn.getFitness());
		double numArc = ar.compute(net, m);
		double numPlace = pl.compute(net, m);
		double numTran = tr.compute(net, m);
		// String density = String.valueOf(de.compute(net, m));
		double cardoso = ca.compute(net, m);
		double PTCD = Math
				.round((0.5 * (numArc / numPlace) + 0.5 * (numArc / numTran)) * 10000) / 10000.0;
		System.out.println("originalCardoso: " + String.valueOf(cardoso)
				+ ", originalPTCD: " + String.valueOf(PTCD));
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		calculateOriginalLogMetrics c = new calculateOriginalLogMetrics();
		c.calculate("C:\\Users\\sun\\Desktop\\4.xes");
	}

}
