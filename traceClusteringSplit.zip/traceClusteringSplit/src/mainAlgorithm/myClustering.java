package mainAlgorithm;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.deckfour.xes.model.XLog;
import org.processmining.models.graphbased.directed.petrinet.Petrinet;
import org.processmining.models.heuristics.HeuristicsNet;
import org.processmining.models.semantics.petrinet.Marking;

import promAlgorithm.FlexibleHeuristicsMiner;
import promAlgorithm.HeuristicsNetToPetriNetConverter;
import promAlgorithm.PetriNetCardosoMetric;
import promAlgorithm.PetriNetDensityMetric;
import promAlgorithm.PetriNetNofArcsMetric;
import promAlgorithm.PetriNetNofPlacesMetric;
import promAlgorithm.PetriNetNofTransitionsMetric;
import assist1.dealWithPattern;
import assist1.generateXES;
import assist1.solveLog;

public class myClustering {

	public void run(String logAddress, String outfold, String patternAddress,
			String numberAddress, Integer singleClusterNumberThreshold,
			double originalPTCD, double min_improvement) {
		Long ll1 = System.currentTimeMillis();
		dealWithPattern dp = new dealWithPattern();
		HashMap<String, String> ns = dp.readNS(numberAddress);
		ArrayList<String> patternList = dp.readInPatterns(ns, patternAddress);
		splitOneLog(logAddress, outfold, patternList,
				singleClusterNumberThreshold, originalPTCD, min_improvement);
		Long ll2 = System.currentTimeMillis();
		System.out.println("splitting algorithm running duration: "
				+ (ll2 - ll1) + "ms");
	}

	public void splitOneLog(String logAddress, String outfold,
			ArrayList<String> patternList,
			Integer singleClusterNumberThreshold, double originalPTCD,
			double min_improvement) {
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		solveLog sl = new solveLog();
		XLog xl = sl.openLogXES(logAddress);
		HashMap<String, String> mapTrace = sl.generateTracesXES(xl);
		String pattern = null;
		String idBoth = null;
		int[] idwith = null;
		int[] idwithout = null;
		int indexWith = 0;
		int indexWithout = 0;
		XLog lwith = null;
		XLog lwithout = null;
		ExecutorService pool = null;
		Callable c1 = null;
		Callable c2 = null;
		Future f1 = null;
		Future f2 = null;
		String[] paraWith = null;
		String[] paraWithout = null;
		// double withCardoso = 0.0;
		double withPTCD = 0.0;
		// double withoutCardoso = 0.0;
		double withoutPTCD = 0.0;
		// double averageCardoso = 0.0;
		double averagePTCD = 0.0;
		double nowImprovement = 0.0;
		double maxImprovement = -10.0;
		String maxIdBoth = null;
		String maxPara = null;
		for (int i = 0; i < patternList.size(); i++) {
			pattern = patternList.get(i);
			idBoth = sl.splitTraces(pattern, mapTrace);
			idwith = sl
					.calculatePositionsXES(xl, idBoth.split("_IDTsplit_")[0]);// //////
			idwithout = sl.calculatePositionsXES(xl,
					idBoth.split("_IDTsplit_")[1]);
			indexWith = idwith.length;
			indexWithout = idwithout.length;
			if (indexWith < singleClusterNumberThreshold
					|| indexWithout < singleClusterNumberThreshold)
				continue;
			lwith = sl.splitLogXES(xl, idwith);
			lwithout = sl.splitLogXES(xl, idwithout);
			System.out
					.println("the" + i + "th"
							+ " pattern is start calculating among "
							+ patternList.size() + " patterns:"
							+ df.format(new Date()));
			pool = Executors.newFixedThreadPool(2);
			c1 = new concurrentC(lwith);// /////////////////////////
			c2 = new concurrentC(lwithout);// ////////////////////////////
			f1 = pool.submit(c1);
			f2 = pool.submit(c2);
			try {
				paraWith = f1.get().toString().split("_Parasplit_");
				System.out.println(paraWith[0] + "_split_" + paraWith[1]);
				paraWithout = f2.get().toString().split("_Parasplit_");
				System.out.println(paraWithout[0] + "_split_" + paraWithout[1]);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ExecutionException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			pool.shutdown();
			// withCardoso = Double.parseDouble(paraWith[0]);
			withPTCD = Double.parseDouble(paraWith[1]);
			// withoutCardoso = Double.parseDouble(paraWithout[0]);
			withoutPTCD = Double.parseDouble(paraWithout[1]);
			// averageCardoso = Math
			// .round(((indexWith * withCardoso + indexWithout
			// * withoutCardoso) / (indexWith + indexWithout)) * 10000) /
			// 10000.0;
			// averageCardoso = Math
			// .round(((withCardoso + withoutCardoso) / 2) * 10000) / 10000.0;
			// averagePTCD = Math.round(((indexWith * withPTCD + indexWithout
			// * withoutPTCD) / (indexWith + indexWithout)) * 10000) / 10000.0;
			averagePTCD = Math.round(((withPTCD + withoutPTCD) / 2) * 10000) / 10000.0;
			nowImprovement = ((originalPTCD - averagePTCD) / originalPTCD);
			if (nowImprovement > maxImprovement) {
				maxImprovement = nowImprovement;
				maxIdBoth = idBoth;
				maxPara = paraWith[0] + "_IDsplit_" + paraWith[1] + "_ItSplit_"
						+ paraWithout[0] + "_IDsplit_" + paraWithout[1];
			}
		}
		if (maxImprovement < min_improvement) {
			System.out.println("should not split the present log");
		} else {
			String[] para = maxPara.split("_ItSplit_");
			System.out.println("withLog: " + para[0] + ", withoutLog: "
					+ para[1]);
			String iWith = maxIdBoth.split("_IDTsplit_")[0];
			String iWithout = maxIdBoth.split("_IDTsplit_")[1];
			output(iWith, mapTrace, outfold, "withMap.xes");
			output(iWithout, mapTrace, outfold, "withoutMap.xes");
		}
	}

	public void output(String ids, HashMap<String, String> mapTrace,
			String outfold, String mark) {
		String[] id = ids.split("_IDsplit_");
		HashMap<String, String> map1 = new HashMap<String, String>();
		for (int i = 0; i < id.length; i++) {
			map1.put(id[i], mapTrace.get(id[i]));
		}
		generateXES g = new generateXES();
		g.generateEventLogWithOutSE(map1, outfold + mark);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// kim: ocardoso:79, oPTCD:3.4797
		// mcrm: ocardoso:64, oPTCD: 2.4545
		// incident: 54, 2.8848
		// repair: 31, 2.3656
		myClustering mc = new myClustering();
		mc.run("C:\\Users\\sun\\Desktop\\traceClustering-splitExperiment\\repair\\oneTimePattern\\1\\withoutMap.xes",
				"C:\\Users\\sun\\Desktop\\traceClustering-splitExperiment\\repair\\oneTimePattern\\2-1-without\\",
				"C:\\Users\\sun\\Desktop\\traceClustering-splitExperiment\\repair\\oneTimePattern\\pattern.txt",
				"C:\\Users\\sun\\Desktop\\traceClustering-splitExperiment\\repair\\oneTimePattern\\Name-Number.txt",
				100, 25, 2.0417, 0, 1, 0);
	}
}

class concurrentC implements Callable {
	public XLog lr = null;

	public concurrentC(XLog lr) {
		this.lr = lr;
	}

	@Override
	public Object call() throws Exception {
		// TODO Auto-generated method stub
		FlexibleHeuristicsMiner miner = new FlexibleHeuristicsMiner(lr);
		HeuristicsNetToPetriNetConverter hv = new HeuristicsNetToPetriNetConverter();
		HeuristicsNet hn = miner.mine();
		Object[] o = hv.converter(hn);
		Petrinet net = (Petrinet) o[0];
		Marking m = (Marking) o[1];
		PetriNetNofArcsMetric ar = new PetriNetNofArcsMetric();
		PetriNetNofPlacesMetric pl = new PetriNetNofPlacesMetric();
		PetriNetNofTransitionsMetric tr = new PetriNetNofTransitionsMetric();
		PetriNetCardosoMetric ca = new PetriNetCardosoMetric();
		PetriNetDensityMetric de = new PetriNetDensityMetric();
		// String fitness = String.valueOf(hn.getFitness());
		double numArc = ar.compute(net, m);
		double numPlace = pl.compute(net, m);
		double numTran = tr.compute(net, m);
		// String density = String.valueOf(de.compute(net, m));
		double cardoso = ca.compute(net, m);
		double PTCD = Math
				.round((0.5 * (numArc / numPlace) + 0.5 * (numArc / numTran)) * 10000) / 10000.0;
		return String.valueOf(cardoso) + "_Parasplit_" + String.valueOf(PTCD);
	}

}