package assist1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class generateXES {

	public ArrayList<String> readInKey(String keyAddress) {
		ArrayList<String> list = new ArrayList<String>();
		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(new File(keyAddress));
			br = new BufferedReader(fr);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String line = null;
		try {
			while ((line = br.readLine()) != null) {
				list.add(line);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	public void generateEventLog(HashMap<String, String> traces,
			String address, String prefix) {
		String[] S = new String[16];
		S[0] = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>";
		S[1] = "<log xes.version=\"1.0\" xmlns=\"http://code.deckfour.org/xes\" xes.creator=\"Yaguang Sun\">";
		S[2] = "<extension name=\"Lifecycle\" prefix=\"lifecycle\" uri=\"http://code.deckfour.org/xes/concept.xesext\"/>";
		S[3] = "<extension name=\"Concept\" prefix=\"concept\" uri=\"http://code.deckfour.org/xes/concept.xesext\"/>";
		S[4] = "<extension name=\"Time\" prefix=\"time\" uri=\"http://code.deckfour.org/xes/time.xesext\"/>";
		S[5] = "<extension name=\"Organizational\" prefix=\"org\" uri=\"http://code.deckfour.org/xes/org.xesext\"/>";
		S[6] = "<global scope=\"trace\">";
		S[7] = "<string key=\"concept:name\" value=\"name\"/>";
		S[8] = "</global>";
		S[9] = "<global scope=\"event\">";
		S[10] = "<string key=\"concept:name\" value=\"name\"/>";
		S[11] = "<string key=\"Activity\" value=\"string\"/>";
		S[12] = "<string key=\"lifecycle:transition\" value=\"Complete\"/>";
		S[13] = "</global>";
		S[14] = "<classifier name=\"Activity\" keys=\"Activity\"/>";
		S[15] = "<classifier name=\"activity classifier\" keys=\"Activity\"/>";
		FileWriter fw = null;
		BufferedWriter bw = null;
		PrintWriter pw = null;
		try {
			fw = new FileWriter(new File(address + prefix));
			bw = new BufferedWriter(fw);
			pw = new PrintWriter(bw);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (int i = 0; i < 16; i++) {
			pw.println(S[i]);
		}
		Set<String> set = traces.keySet();
		Iterator iterator = set.iterator();
		ArrayList<String> kset = new ArrayList<String>();
		while (iterator.hasNext()) {
			kset.add(iterator.next().toString());
		}
		String key = null;
		String[] value = null;
		for (int i = 0; i < kset.size(); i++) {
			key = kset.get(i);
			value = traces.get(key).split(" ");
			pw.println("<trace>");
			pw.println("<string key=\"concept:name\" value=\"" + key + "\"/>");
			pw.println("<event>");
			pw.println("<string key=\"concept:name\" value=\""
					+ "startActivity" + "\"/>");
			pw.println("<string key=\"Activity\" value=\"" + "startActivity"
					+ "\"/>");
			pw.println("<string key=\"lifecycle:transition\" value=\""
					+ "complete" + "\"/>");
			pw.println("</event>");
			for (int j = 0; j < value.length; j++) {

				pw.println("<event>");
				pw.println("<string key=\"concept:name\" value=\"" + value[j]
						+ "\"/>");
				// //����ʡ����timestamp������promʶ����
				// pw.println("<string key=\"time:timestamp\" value=\""
				// + value[j].split(":")[0] + "\"/>");
				pw.println("<string key=\"Activity\" value=\"" + value[j]
						+ "\"/>");
				pw.println("<string key=\"lifecycle:transition\" value=\""
						+ "complete" + "\"/>");
				pw.println("</event>");
			}
			pw.println("<event>");
			pw.println("<string key=\"concept:name\" value=\"" + "endActivity"
					+ "\"/>");
			pw.println("<string key=\"Activity\" value=\"" + "endActivity"
					+ "\"/>");
			pw.println("<string key=\"lifecycle:transition\" value=\""
					+ "complete" + "\"/>");
			pw.println("</event>");
			pw.println("</trace>");
		}
		pw.println("</log>");
		pw.close();
	}

	public void generateEventLogWithOutSE(HashMap<String, String> traces,
			String address) {
		String[] S = new String[16];
		S[0] = "<?xml version=\"1.0\" encoding=\"UTF-8\" ?>";
		S[1] = "<log xes.version=\"1.0\" xmlns=\"http://code.deckfour.org/xes\" xes.creator=\"Yaguang Sun\">";
		S[2] = "<extension name=\"Lifecycle\" prefix=\"lifecycle\" uri=\"http://code.deckfour.org/xes/concept.xesext\"/>";
		S[3] = "<extension name=\"Concept\" prefix=\"concept\" uri=\"http://code.deckfour.org/xes/concept.xesext\"/>";
		S[4] = "<extension name=\"Time\" prefix=\"time\" uri=\"http://code.deckfour.org/xes/time.xesext\"/>";
		S[5] = "<extension name=\"Organizational\" prefix=\"org\" uri=\"http://code.deckfour.org/xes/org.xesext\"/>";
		S[6] = "<global scope=\"trace\">";
		S[7] = "<string key=\"concept:name\" value=\"name\"/>";
		S[8] = "</global>";
		S[9] = "<global scope=\"event\">";
		S[10] = "<string key=\"concept:name\" value=\"name\"/>";
		S[11] = "<string key=\"Activity\" value=\"string\"/>";
		S[12] = "<string key=\"lifecycle:transition\" value=\"Complete\"/>";
		S[13] = "</global>";
		S[14] = "<classifier name=\"Activity\" keys=\"Activity\"/>";
		S[15] = "<classifier name=\"activity classifier\" keys=\"Activity\"/>";
		FileWriter fw = null;
		BufferedWriter bw = null;
		PrintWriter pw = null;
		try {
			fw = new FileWriter(new File(address));
			bw = new BufferedWriter(fw);
			pw = new PrintWriter(bw);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (int i = 0; i < 16; i++) {
			pw.println(S[i]);
		}
		Set<String> set = traces.keySet();
		Iterator iterator = set.iterator();
		ArrayList<String> kset = new ArrayList<String>();
		while (iterator.hasNext()) {
			kset.add(iterator.next().toString());
		}
		String key = null;
		String[] value = null;
		for (int i = 0; i < kset.size(); i++) {
			key = kset.get(i);
			if(traces.get(key)==null)
				System.out.println(key);
			value = traces.get(key).split("_Asplit_");
			pw.println("<trace>");
			pw.println("<string key=\"concept:name\" value=\"" + key + "\"/>");
			for (int j = 0; j < value.length; j++) {
				String[] mm = value[j].split("_Tsplit_");
				String mmm = mm[0];
				String mmmm = mm[1];
				pw.println("<event>");
				pw.println("<string key=\"concept:name\" value=\"" + mmm
						+ "\"/>");
				// //����ʡ����timestamp������promʶ����
				// pw.println("<string key=\"time:timestamp\" value=\""
				// + value[j].split(":")[0] + "\"/>");
				pw.println("<string key=\"Activity\" value=\"" + mmm + "\"/>");
				pw.println("<string key=\"lifecycle:transition\" value=\""
						+ mmmm + "\"/>");
				pw.println("</event>");
			}
			pw.println("</trace>");
		}
		pw.println("</log>");
		pw.close();
	}

	public void run(String keyAddress, String logAddress, String outAddress) {
		ArrayList<String> key = readInKey(keyAddress);
		HashMap<String, String> traces = null;
		generateEventLog(traces, outAddress, "");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		generateXES g = new generateXES();
		g.run("C:\\Users\\sun\\Desktop\\forLoan\\60total.txt",
				"C:\\Users\\sun\\Desktop\\BPI_Challenge_2012.xes",
				"C:\\Users\\sun\\Desktop\\forLoan\\60total.xes");
	}

}
