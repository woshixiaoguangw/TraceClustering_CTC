package assist1;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class dealWithPattern {
	// �����ȡname�����ֵ�map
	public HashMap<String, String> readSN(String address) {
		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(new File(address));
			br = new BufferedReader(fr);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String line = null;
		HashMap<String, String> m = new HashMap<String, String>();
		try {
			while ((line = br.readLine()) != null) {
				m.put(line.split("_NNsplit_")[0], line.split("_NNsplit_")[1]);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return m;
	}

	// �����ȡ���ֶ�name��map
	public HashMap<String, String> readNS(String address) {
		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(new File(address));
			br = new BufferedReader(fr);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String line = null;
		HashMap<String, String> m = new HashMap<String, String>();
		try {
			while ((line = br.readLine()) != null) {
				m.put(line.split("_NNsplit_")[1], line.split("_NNsplit_")[0]);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return m;
	}

	public ArrayList<String> readInPatterns(HashMap<String, String> ns,
			String address) {
		FileReader fr = null;
		BufferedReader br = null;
		try {
			fr = new FileReader(new File(address));
			br = new BufferedReader(fr);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String line = null;
		String[] tem1 = null;
		String tem2 = null;
		ArrayList<String> list = new ArrayList<String>();
		try {
			while ((line = br.readLine()) != null) {
				tem1 = line.split(" -1 ");
				for (int i = 0; i < tem1.length - 1; i++) {
					if (i == 0)
						tem2 = ns.get(tem1[i]);
					else
						tem2 = tem2 + "_Asplit_" + ns.get(tem1[i]); // _Psplit_����pattern��activity
				}
				list.add(tem2 + "_FRsplit_" // ����pattern��Ƶ��ֵ
						+ tem1[tem1.length - 1].split(": ")[1]);
				tem2 = null;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

	// ��ӡ�õ���traceMap������bide��Ҫ�ĸ�ʽ
	public void output(HashMap<String, String> mm,
			HashMap<String, String> traceMap, String address) {
		FileWriter fw = null;
		BufferedWriter bw = null;
		PrintWriter pw = null;
		try {
			fw = new FileWriter(new File(address));
			bw = new BufferedWriter(fw);
			pw = new PrintWriter(bw);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		String s2 = null;
		String s3 = null;
		String[] s1 = null;
		String tem = null;
		Set<String> set = traceMap.keySet();
		Iterator iterator = set.iterator();
		ArrayList<String> kset = new ArrayList<String>();
		while (iterator.hasNext()) {
			kset.add(iterator.next().toString());
		}
		String key = null;
		String value = null;
		for (int m = 0; m < kset.size(); m++) {
			key = kset.get(m);
			s1 = traceMap.get(key).split("_Asplit_");
			for (int i = 0; i < s1.length; i++) {
				if (i == 0 && s1.length == 1)
					tem = mm.get(s1[i]) + " -1 -2";
				else if (i == 0)
					tem = mm.get(s1[i]);
				else if (i == (s1.length - 1))
					tem = tem + " -1 " + mm.get(s1[i]) + " -1 -2";
				else
					tem = tem + " -1 " + mm.get(s1[i]);
			}
			pw.println(tem);
		}
		pw.close();
	}

	// �ж�pattern����Ŀ�Ƿ�Ϸ������Ϸ����Ƴ�
	public ArrayList<String> deleteWrongPatterns(Integer nuIns,
			ArrayList<String> cpList, double min_sup, Integer sita) {
		ArrayList<String> list = new ArrayList<String>();
		String[] pattern = null;
		int frequency = 0;
		int another = 0;
		int judge1 = (int) Math.round(min_sup * nuIns);
		int judge2 = sita;
		for (int i = 0; i < cpList.size(); i++) {
			pattern = cpList.get(i).split("_FRsplit_");
			frequency = Integer.parseInt(pattern[1]);
			another = nuIns - frequency;
			if (frequency >= judge1 && frequency >= judge2 && another >= judge1
					&& another >= judge2)
				list.add(cpList.get(i));
		}
		return list;
	}
    // next do the 
	public ArrayList<String> deleteWrongPatternsForOnePattern(Integer up,
			ArrayList<String> cpList, Integer low) {
		ArrayList<String> list = new ArrayList<String>();
		String[] pattern = null;
		int frequency = 0;
		for (int i = 0; i < cpList.size(); i++) {
			pattern = cpList.get(i).split("_FRsplit_");
			frequency = Integer.parseInt(pattern[1]);
			if (frequency >= low && frequency <= up)
				list.add(cpList.get(i));
		}
		return list;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		dealWithPattern b = new dealWithPattern();
		// System.out.println(b.getCluster(" clusters: 2"));
		// HashMap<String, String> mm =
		// b.readSN("D:\\test\\forLoan\\ANumber.txt");
		// HashMap<String, String> mapTrace = b
		// .readIn("D:\\test\\forLoan\\for0.4\\forP1With1\\forP1With1\\log.xes");
		// System.out.println(mapTrace.size());
		// b.output(mm, mapTrace,
		// "D:\\test\\forLoan\\for0.4\\forP1With1\\forP1With1\\bideForLoanNumber.txt");
		HashMap<String, String> ns = b
				.readNS("C:\\Users\\sun\\Desktop\\newTestClusteringTraces\\forRepair\\Name-Number.txt");
		System.out
				.println(b
						.readInPatterns(ns,
								"C:\\Users\\sun\\Desktop\\newTestClusteringTraces\\forRepair\\pattern.txt"));
	}
}
