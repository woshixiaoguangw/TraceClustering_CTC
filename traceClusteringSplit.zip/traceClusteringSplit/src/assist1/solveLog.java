package assist1;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import org.deckfour.xes.factory.XFactoryNaiveImpl;
import org.deckfour.xes.in.XesXmlParser;
import org.deckfour.xes.model.XEvent;
import org.deckfour.xes.model.XLog;
import org.deckfour.xes.model.XTrace;

public class solveLog {

	// �÷���Ϊһ��xeslog��ȡ
	public XLog openLogXES(String address) {
		ArrayList<XLog> list = null;
		FileInputStream fis = null;
		BufferedInputStream bis = null;
		XesXmlParser xxp = null;
		try {
			fis = new FileInputStream(address);
			bis = new BufferedInputStream(fis);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		xxp = new XesXmlParser();
		XLog log = null;
		try {
			list = (ArrayList<XLog>) xxp.parse(bis);
			log = list.get(0);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return log;
	}

	// Ϊxes��־ ����������Ҫ��traces����
	public HashMap<String, String> generateTracesXES(XLog lr) {
		HashMap<String, String> mapTrace = new HashMap<String, String>();
		String s = null; // �����洢trace
		Integer m = 0;
		String index = null;
		for (XTrace trace : lr) {
			index = trace.getAttributes().get("concept:name").toString();
			for (XEvent event : trace) {
				m++;
				if (m == 1) {
					s = event.getAttributes().get("concept:name").toString()
							+ "_Tsplit_" // name��transition֮��ķ������������
							+ event.getAttributes().get("lifecycle:transition")
									.toString();
				} else if (m == trace.size()) {
					s = s
							+ "_Asplit_" // activity��activity֮�����������
							+ event.getAttributes().get("concept:name")
									.toString()
							+ "_Tsplit_"
							+ event.getAttributes().get("lifecycle:transition")
									.toString();
				} else {
					s = s
							+ "_Asplit_"
							+ event.getAttributes().get("concept:name")
									.toString()
							+ "_Tsplit_"
							+ event.getAttributes().get("lifecycle:transition")
									.toString();
				}

			}
			// String fs = checkDuplicatedActivity(s);
			mapTrace.put(index, s);
			m = 0;
		}
		return mapTrace;
	}

	// ����pattern��split traces,�����������ϵ�����trace��id
	public String splitTraces(String pattern, HashMap<String, String> mapTrace) {
		judgeSubSeq jss = new judgeSubSeq();
		String patt = pattern.split("_FRsplit_")[0];
		Set<String> set = mapTrace.keySet();
		Iterator iterator = set.iterator();
		ArrayList<String> kset = new ArrayList<String>();
		while (iterator.hasNext()) {
			kset.add(iterator.next().toString());
		}
		String key = null;
		String value = null;
		int leng = patt.split("_Asplit_").length;
		int index = 0;
		String temW = null;
		String temWT = null;
		for (int i = 0; i < kset.size(); i++) {
			key = kset.get(i);
			value = mapTrace.get(key);
			index = jss.findLNCS1(value, patt);
			// System.out.println(index);
			if (index == leng) {
				if (temW == null)
					temW = key;
				else
					temW = temW + "_IDsplit_" + key;// IDsplit����id
			} else {
				if (temWT == null)
					temWT = key;
				else
					temWT = temWT + "_IDsplit_" + key;
			}
		}
		return temW + "_IDTsplit_" + temWT;
		// ��������id��trace��������Ÿ���,ǰ�����pattern��traces�����治����
	}

	// ����xeslog���ݸ���instances��λ��ѡ������instance��ɸ��µ���־
	public XLog splitLogXES(XLog lr, int[] t) {
		XFactoryNaiveImpl xn = new XFactoryNaiveImpl();
		XLog log1 = xn.createLog();
		Integer index = 0;
		for (int i = 0; i < t.length; i++) {
			index = t[i];
			log1.add(lr.get(index));
		}
		return log1;
	}

	// Ϊxeslog����id���ϼ���traces��λ��
	public int[] calculatePositionsXES(XLog lr, String idd) {
		ArrayList<String> id = new ArrayList<String>();
		String[] idds = idd.split("_IDsplit_");
		for (int i = 0; i < idds.length; i++)
			id.add(idds[i]);
		ArrayList<Integer> list = new ArrayList<Integer>();
		int d = 0;
		for (XTrace trace : lr) {
			if (id.contains(trace.getAttributes().get("concept:name")
					.toString()))
				list.add(d);
			d++;
		}
		int[] t = new int[list.size()];
		for (int i = 0; i < list.size(); i++)
			t[i] = list.get(i);
		return t;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		solveLog r = new solveLog();
		String pattern = "a_Asplit_b_Asplit_d_FRsplit_43";
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("1", "a_Asplit_e_Asplit_d_Asplit_f_Asplit_b_Asplit_d");
		map.put("2", "a");
		map.put("3", "a_Asplit_e_Asplit_f_Asplit_b");
		map.put("4", "a_Asplit_e_Asplit_d_Asplit_f_Asplit_f_Asplit_q");
		System.out.println(r.splitTraces(pattern, map));
	}

}
